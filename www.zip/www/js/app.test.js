describe('PhoneListCtrl', function(){
  
    it('is just a test', function() {
      expect(1).toEqual(0);
    });
  })